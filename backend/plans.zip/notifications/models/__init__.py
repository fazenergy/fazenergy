from .config_email import EmailConfig
from .template import NotificationTemplate

__all__ = ['EmailConfig', 'NotificationTemplate']
