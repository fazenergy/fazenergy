from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

    def ready(self):
        import finance.signals  # Importa o signals.py
        import core.signals  # ajusta conforme sua estrutura
