from .models import *

# Só serve pra Django localizar tudo.
# Não é necessário importar nada aqui.